<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use PhpParser\Node\Stmt\TryCatch;

class GoogleController extends Controller
{
   public function redirectGoogle()
   {
    return Socialite::driver('google')->redirect();
   }

   public function callbackGoogle()
   {
        try {
            $user = Socialite::driver('google')->user();

            $finduser = User::where('google_id',$user->getId())->first();
            dd($user->id);
            if($finduser)
            {
                Auth::login($finduser);
                return redirect()->view('home');
            }

            else
            {
                $new = User::create([
                    'name'=> $user->name,
                    'username' => $user->email,
                    'email' => $user->email,
                    'google_id' => $user->id,
                    'password' => bcrypt('123456789')
                ]);

                Auth::login($new);
                return redirect()->view('home');
            }
        } catch (\Throwable $th) {

        }
   }
}
